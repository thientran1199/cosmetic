
<?php $__env->startSection('title', 'Order '); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Dashboard</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="#">Dashboard</a></li>
                                <li><a href="#">Menu</a></li>
                                <li class="active">Data List</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Order Table</strong>
                            
                            
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Customer</th>
                                        <th scope="col">Note</th>
                                        <th scope="col">Address</th>
                                        <th scope="col">Total Price</th>
                                        <th scope="col">User</th>
                                        
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>  
                                        <th scope="row"><?php echo e($item->id); ?></th>
                                        <td><?php echo e($item->customers->name); ?></td>
                                        <td><?php echo e($item->note); ?></td>
                                        <td><?php echo e($item->address); ?></td>
                                        <td><?php echo e($item->total_price); ?></td>
                                        <td><?php echo e($item->users->name); ?></td>
                                        
                                        
                                        <td>
                                            
                                            <a href="#"><button type="button" class="btn btn-outline-success" 
                                                data-toggle="modal" data-target="#view_<?php echo e($item->id); ?>"><i class="fa fa-eye"></i>&nbsp; View</button></a>
                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('order-delete')): ?>
                                            <a href="<?php echo e(route('order.delete', $item->id)); ?>"><button type="button" class="btn btn-outline-danger"><i class="fa fa-trash"></i>&nbsp; Delete</button></a>
                                            <?php else: ?>
                                            <a href="<?php echo e(route('403')); ?>"><button type="button" class="btn btn-outline-danger" disabled><i class="fa fa-trash"></i>&nbsp; Delete</button></a>
                                            <?php endif; ?>
                                            
                                        </td>
                                    </tr>
                                    <?php echo $__env->make('admin.orders.popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                    
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>



        </div>


    </div><!-- .animated -->
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\MyPham\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>