<!-- HightLight  -->
        <div class="main__frame">
            <div class="grid wide">
                <h3 class="category__title">Ngọc Ánh Cometics</h3>
                <h3 class="category__heading">SẢN PHẨM NỔI BẬT</h3>
                <div class="owl-carousel hight owl-theme">

                    <?php $__currentLoopData = $productRecommand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                    <div class="product">
                        <div class="product__avt" style="background-image: url(<?php echo e(asset($item->feature_image_path)); ?>);">
                        </div>
                        <div class="product__info">
                            <h3 class="product__name"><?php echo e($item->name); ?></h3>
                            <div class="product__price">
                                <?php if($item->promotion_price !=0  ): ?>
                                        <div class="price__old">
                                            <?php echo e(number_format($item->promotion_price)); ?> đ
                                        </div>
                                        <div class="price__new"><?php echo e(number_format($item->price)); ?> <span class="price__unit">đ</span></div>
                                        
                                        <?php else: ?>                                     
                                        <div class="price__new"><?php echo e(number_format($item->price)); ?> <span class="price__unit">đ</span></div>
                                       
                                        <?php endif; ?>
                            </div>
                            <div class="product__sale">
                                <span class="product__sale-percent">23</span>
                                <span class="product__sale-text">Giảm</span>
                            </div>
                        </div>
                        <a href="<?php echo e(route('product.detail',$item->id)); ?>" class="viewDetail">Xem chi tiết</a>
                        <a href="#" onclick="addCart(<?php echo e($item->id); ?>)" class="addToCart">Thêm vào giỏ</a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div><?php /**PATH C:\laragon\www\MyPham\resources\views/home/feature_product/feature_product.blade.php ENDPATH**/ ?>