<!-- Slider -->
<div class="main__slice">
    <div class="slider">
        <?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        <div class="slide active" style="background-image:url(<?php echo e(asset($item->image_path)); ?>)">
            <div class="container">
                <div class="caption">
                    <h1><?php echo e($item->title); ?></h1>
                    <p><?php echo e($item->description); ?></p>
                    <a href="#" class="btn btn--default">Xem ngay</a>

                </div>
            </div>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- controls  -->
    <div class="controls">
        <div class="prev">
            <i class="fas fa-chevron-left"></i>
        </div>
        <div class="next">
            <i class="fas fa-chevron-right"></i>
        </div>
    </div>
    <!-- indicators -->
    <div class="indicator">
    </div>
</div><?php /**PATH C:\laragon\www\MyPham\resources\views/home/layouts/slide.blade.php ENDPATH**/ ?>