<!DOCTYPE html>
<html lang="en">
<!-- https://cocoshop.vn/ -->
<!-- http://mauweb.monamedia.net/vanihome/ -->

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giỏ hàng</title>
    <!-- Font roboto -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Icon fontanwesome -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <!-- Reset css & grid sytem -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/library.css')); ?>">
    <!-- Owl Slider css -->
    <link rel="stylesheet" href="assets/owlCarousel/assets/owl.carousel.min.css') }}">
    <link rel="stylesheet" href="assets/owlCarousel/assets/owl.theme.default.min.css') }}">
    <!-- Layout -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/common.css')); ?>">
    <!-- index -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/assets/css/cart.css')); ?>">
    <!-- Jquery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Owl caroucel Js-->
    <script src="<?php echo e(asset('frontend/assets/owlCarousel/owl.carousel.min.js')); ?>"></script>
</head>

<body>
   <?php echo $__env->make('home.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <div class="main">
    <div class="grid wide">
        <h3 class="main__notify">
            <div class="main__notify-icon">
                <i class="fas fa-check"></i>
                <!-- <i class="fas fa-times"></i> -->
            </div>
            <div class="main__notify-text">Giỏ hàng đã được cập nhật.</div>
        </h3>
        <div class="row">
            <div class="col l-8 m-12 s-12">
                <div class="main__cart">
                    <div class="row title">
                        <div class="col l-1 m-1 s-0">Chọn</div>
                        <div class="col l-4 m-4 s-8">Sản phẩm</div>
                        <div class="col l-2 m-2 s-0">Giá</div>
                        <div class="col l-2 m-2 s-0">Số lượng</div>
                        <div class="col l-2 m-2 s-4">Tổng</div>
                        <div class="col l-1 m-1 s-0">Xóa</div>
                    </div>
                    <?php
                        $cart = session()->has('cart') ? session('cart') : null;
                    ?>
                    <?php if($cart==null): ?>
                        <p class="text-center">Chưa có sản phẩm nào trong giỏ hàng</p>
                    <?php else: ?>
                    <?php $__currentLoopData = $cart->getListCartItem(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row item">
                        <div class="col l-1 m-1 s-0">
                            <input type="checkbox" name="a">
                        </div>
                        <div class="col l-4 m-4 s-8">
                            <div class="main__cart-product">
                                <img src="<?php echo e(asset('frontend/assets/img/product/product2.jpg')); ?>" alt="">
                                <div class="name">ss</div>
                            </div>
                        </div>
                        <div class="col l-2 m-2 s-0">
                            <div class="main__cart-price">476.000 đ</div>
                        </div>
                        <div class="col l-2 m-2 s-0">
                            <div class="buttons_added">
                                <input class="minus is-form" type="button" value="-" onclick="minusProduct()">
                                <input aria-label="quantity" class="input-qty" max="10" min="1" name="" type="number" value="1">
                                <input class="plus is-form" type="button" value="+" onclick="plusProduct()">
                            </div>
                        </div>
                        <div class="col l-2 m-2 s-4">
                            <div class="main__cart-price">476.000 đ</div>
                        </div>
                        <div class="col l-1 m-1 s-0">
                            <span class="main__cart-icon">
                            <i class="far fa-times-circle "></i>
                        </span>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="btn btn--default">
                        Cập nhật giỏ hàng
                    </div>
                   
                </div>
            </div>
            <div class="col l-4 m-12 s-12">
                <div class="main__pay">
                    <div class="main__pay-title">Tổng số lượng</div>
                    <div class="pay-info">
                        <div class="main__pay-text">
                            Tổng phụ</div>
                        <div class="main__pay-price">
                            1,120,000 ₫
                        </div>
                    </div>
                    <div class="pay-info">
                        <div class="main__pay-text">
                            Giao hàng
                        </div>
                        <div class="main__pay-text">
                            Giao hàng miễn phí
                        </div>

                    </div>
                    <div class="pay-info">
                        <div class="main__pay-text">
                            Tổng thành tiền</div>
                        <div class="main__pay-price">
                            1,120,000 ₫
                        </div>
                    </div>
                    <div class="btn btn--default orange">Tiến hành thanh toán</div>
                    <div class="main__pay-title">Phiếu ưu đãi</div>
                    <input type="text" class="form-control">
                    <div class="btn btn--default">Áp dụng</div>
                </div>
            </div>
        </div>
    </div>
</div>

    <?php echo $__env->make('home.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Modal Form -->
    <?php echo $__env->make('home.modal_popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Sccipt for owl caroucel -->

    <!-- Script common -->
    <script src="<?php echo e(asset('frontend/assets/js/commonscript.js')); ?>"></script>


</body>

</html><?php /**PATH C:\laragon\www\MyPham\resources\views/home/cart/cart.blade.php ENDPATH**/ ?>