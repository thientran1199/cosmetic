<!-- Left Panel -->
<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">
        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="<?php echo e(request()->is('/dasboard') ? 'active' : ''); ?>">
                    <a href="#"><i class="menu-icon fa fa-laptop"></i>Dashboard </a>
                </li>
                <li class="menu-title">Page</li><!-- /.menu-title -->
                
                <li class="menu-item-has-children dropdown <?php echo e(request()->is('domain*') ? 'active' : ''); ?>">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-cogs"></i>Domain</a>
                    <ul class="sub-menu children dropdown-menu">                            
                        <li><i class="fa fa-bars"></i><a href="">List</a></li>
                        <li><i class="fa fa-plus"></i><a href="">Add</a></li>
                     
                    </ul>
                </li>
                
                
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</aside>
<!-- /#left-panel --><?php /**PATH C:\laragon\www\MyPham\resources\views/layouts/left_panel.blade.php ENDPATH**/ ?>