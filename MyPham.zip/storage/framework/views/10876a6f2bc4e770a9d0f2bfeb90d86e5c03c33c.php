<div class="modal fade" id="view_<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="largeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            
            <div class="modal-body">
                    <h3 class="title" style="text-align: center;
                   
                    font-family: cursive;
                    font-weight: bold;">View Product</h3>
                    <hr>
                <h5><label for="">ID: &nbsp;</label><?php echo e($item->id); ?></h5>
                <h5><label for="">Name: &nbsp;</label><?php echo e($item->name); ?></h5>
                <h5><label for="">User: &nbsp;</label><?php echo e(auth()->user()->name); ?></h5>
                <h5><label for="">Category: &nbsp;</label><?php echo e($item->category->name); ?></h5>
                <h5><label for="">Price: &nbsp;</label><?php echo e(number_format($item->price)); ?></h5>
                <h5><label for="">Promtion Price: &nbsp;</label>
                    <?php if($item->promotion_price == 0): ?>
                    Products not yet on promotion
                    <?php else: ?>
                    <?php echo e(number_format($item->promotion_price)); ?>

                    <?php endif; ?>
                </h5>
                <hr>
                <h5><label for="">Image Name: &nbsp;</label><?php echo e($item->feature_image_name); ?></h5>
                <h5><label for="">Image Path: &nbsp;</label><?php echo e($item->feature_image_path); ?></h5>
                <h5><label for="">Image: &nbsp;</label><br>
                <img src="<?php echo e(asset($item->feature_image_path)); ?>" width="300px" height="300px" alt="">
                </h5>
                <hr>
                <h5><label for="">Image Detail: &nbsp;</label><br>
                <?php $__currentLoopData = $item->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e(asset($i->image_path)); ?>" width="250px" height="200px" alt="">
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                
                </h5>
                <hr>
                <h5><label for="">Content: &nbsp;</label><?php echo $item->content; ?></h5>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\MyPham\resources\views/admin/product/popup.blade.php ENDPATH**/ ?>