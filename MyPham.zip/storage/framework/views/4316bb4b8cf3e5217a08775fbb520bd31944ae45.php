<div class="modal fade" id="view_<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="largeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            
            <div class="modal-body">
                    <h3 class="title" style="text-align: center;
                   
                    font-family: cursive;
                    font-weight: bold;">View Detail</h3>
                    <hr>
                
                <h5><label for="">ID: &nbsp;</label><?php echo e($item->id); ?></h5>
                <h5><label for="">OrderID: &nbsp;</label><?php echo e($item->orders->id); ?></h5>
                <h5><label for="">Product: &nbsp;</label><?php echo e($item->products->name); ?></h5>
                <h5><label for="">Quantity: &nbsp;</label><?php echo e($item->quantity); ?></h5>
                <h5><label for="">Price: &nbsp;</label><?php echo e(number_format($item->price)); ?></h5>
                
                
                
                
                
            
                
                </h5>
                <hr>
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\MyPham\resources\views/admin/orderdetail/popup.blade.php ENDPATH**/ ?>