
<?php $__env->startSection('title', 'Slide '); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="breadcrumbs">
        <div class="breadcrumbs-inner">
            <div class="row m-0">
                <div class="col-sm-4">
                    <div class="page-header float-left">
                        <div class="page-title">
                            <h1>Dashboard</h1>
                        </div>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="page-header float-right">
                        <div class="page-title">
                            <ol class="breadcrumb text-right">
                                <li><a href="#">Dashboard</a></li>
                                <li><a href="#">Slide</a></li>
                                <li class="active">Data List</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="content">
        <div class="animated fadeIn">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Slide Table</strong>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('slide-add')): ?>
                            <a href="<?php echo e(route('slide.create')); ?>" style="float: right;"><button type="button" class="btn btn-outline-success"><i class="fa fa-plus"></i>&nbsp; ADD DATA</button></a>
                            <?php else: ?>
                            <a href="<?php echo e(route('403')); ?>" style="float: right;"><button type="button" class="btn btn-outline-success" disabled><i class="fa fa-plus"></i>&nbsp; ADD DATA</button></a>
                            <?php endif; ?>
                            
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Title</th>
                                        <th scope="col">Description</th>
                                        
                                        
                                        <th scope="col">Image</th>
                                        
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>  
                                        <th scope="row"><?php echo e($item->id); ?></th>
                                        <td><?php echo e($item->title); ?></td>
                                        <td><?php echo e($item->description); ?></td>
                                  
                                        
                                        <td><img  class="img_slide" src="<?php echo e(asset($item->image_path)); ?>" 
                                             alt=""></td>
                                        
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('slide-edit')): ?>
                                            <a href="<?php echo e(route('slide.edit', $item->id)); ?>"><button type="button" class="btn btn-outline-success"><i class="fa fa-pencil"></i>&nbsp; Edit</button></a>
                                            <?php else: ?>
                                            <a href="<?php echo e(route('403')); ?>"><button type="button" class="btn btn-outline-success" disabled><i class="fa fa-pencil"></i>&nbsp; Edit</button></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('slide-delete')): ?>
                                            <a href="<?php echo e(route('slide.delete', $item->id)); ?>"><button type="button" class="btn btn-outline-danger"><i class="fa fa-trash"></i>&nbsp; Delete</button></a>
                                            <?php else: ?>
                                            <a href="<?php echo e(route('403')); ?>"><button type="button" class="btn btn-outline-danger" disabled><i class="fa fa-trash"></i>&nbsp; Delete</button></a>
                                            <?php endif; ?>
                                            
                                        
                                        
                                        
                                        </td>
                                    </tr>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                </div>

            </div>



        </div>


    </div><!-- .animated -->
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\MyPham\resources\views/admin/slide/index.blade.php ENDPATH**/ ?>