<div class="header scrolling" id="myHeader">
    <div class="grid wide">
        <div class="header__top">
            <div class="navbar-icon">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <a href="index.html" class="header__logo">
                <img src="<?php echo e(asset('frontend/assets/logo.png')); ?>" alt="">
            </a>
            <div class="header__search">
                <div class="header__search-wrap">
                    <input type="text" class="header__search-input" placeholder="Tìm kiếm">
                    <a class="header__search-icon" href="#">
                        <i class="fas fa-search"></i>
                    </a>
                </div>
            </div>
            <div class="header__account">
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                    
                        <a href="#my-Login" class="header__account-login">Đăng Nhập</a>
                    
                    <?php endif; ?>
                    <?php if(Route::has('register')): ?>
                    
                        <a href="#my-Register" class="header__account-register">Đăng Kí</a>
                    
                    <?php endif; ?>
                    <?php else: ?>
                    <a href="#" class="header__account-login"><?php echo e(Auth::user()->name); ?></a>
                    <a href="<?php echo e(route('logout')); ?>" class="header__account-register" 
                    onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">Đăng Xuat</a> 
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                <?php endif; ?> 
                
                
            </div>
            <!-- Cart -->
            <div class="header__cart have" href="">
                <i class="fas fa-shopping-basket"></i>
                <div class="header__cart-amount">
                    <?php if(Session::get("cart") != null): ?>
                        <span id="count-cart"><?php echo e(Session::get("cart")->totalQty); ?></span>
                    <?php else: ?>
                    <span id="count-cart">0</span>
                    <?php endif; ?> 
                   
                </div>
                <div id="change-item-cart">
                   <?php echo $__env->make('cart.minicart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            
            </div>
        </div>
    </div>
   <?php echo $__env->make('home.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH C:\laragon\www\MyPham\resources\views/home/layouts/header.blade.php ENDPATH**/ ?>