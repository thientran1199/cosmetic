<div class="modal fade" id="view_<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="largeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            
            <div class="modal-body">
                    <h3 class="title" style="text-align: center;
                   
                    font-family: cursive;
                    font-weight: bold;">View Detail</h3>
                    <hr>
                
                <h5><label for="">Name: &nbsp;</label><?php echo e($item->note); ?></h5>
                <h5><label for="">User: &nbsp;</label></h5>
                <h5><label for="">Category: &nbsp;</label>/h5>
                <h5><label for="">Price: &nbsp;</label></h5>
                
                
                
            
                
                </h5>
                <hr>
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
                
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\MyPham\resources\views/admin/orders/popup.blade.php ENDPATH**/ ?>