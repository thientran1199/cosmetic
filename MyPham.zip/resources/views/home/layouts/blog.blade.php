  <!-- News -->
  <div class="main__frame bg-3">
    <div class="grid wide">
        <h3 class="category__title">Ngọc Ánh Cometics</h3>
        <h3 class="category__heading">Tin Tức</h3>
        <div class="owl-carousel news owl-theme">
            <a href="news.html" class="news">
                <div class="news__img">
                    <img src="./assets/img/news/news1.jpg" alt="">
                </div>
                <div class="news__body">
                    <h3 class="news__body-title">Trang điểm đúng cách</h3>
                    <div class="new__body-date">13/6/2021</div>
                    <p class="news__description">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. In sit molestiae aperiam modi cum deserunt, maxime blanditiis voluptate officiis accusantium minima pariatur harum tenetur quo iste iusto commodi. Modi, culpa?
                    </p>
                </div>
            </a>
            <a href="news.html" class="news">
                <div class="news__img">
                    <img src="./assets/img/news/news1.jpg" alt="">
                </div>
                <div class="news__body">
                    <h3 class="news__body-title">Trang điểm đúng cách</h3>
                    <div class="new__body-date">13/6/2021</div>
                    <p class="news__description">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. In sit molestiae aperiam modi cum deserunt, maxime blanditiis voluptate officiis accusantium minima pariatur harum tenetur quo iste iusto commodi. Modi, culpa?
                    </p>
                </div>
            </a>
            <a href="news.html" class="news">
                <div class="news__img">
                    <img src="./assets/img/news/news1.jpg" alt="">
                </div>
                <div class="news__body">
                    <h3 class="news__body-title">Trang điểm đúng cách</h3>
                    <div class="new__body-date">13/6/2021</div>
                    <p class="news__description">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. In sit molestiae aperiam modi cum deserunt, maxime blanditiis voluptate officiis accusantium minima pariatur harum tenetur quo iste iusto commodi. Modi, culpa?
                    </p>
                </div>
            </a>
        </div>
    </div>
</div>