<?php

    return [
        'access' => [
            'list-category'=>'category_list',
            'add-category'=>'category_add',
        ],
        'table_module'=> [
            'category',
            'slide',
            'menu',
            'product',
            'setting',
            'user',
            'role',
        ],
        'module_child' => [
            'list',
            'add',
            'edit',
            'delete',
        ]
    ];

?>